//
//  ReservationDetailsCell.swift
//  ReservationSampleApp
//
//  Created by Subashree on 15/03/17.
//  Copyright © 2017 Subashree. All rights reserved.
//

import UIKit

class ReservationDetailsCell: UITableViewCell {

    @IBOutlet weak var btnReserve: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var lblSpaCount: UILabel!
    @IBOutlet weak var lblSpaDetails: UILabel!
    @IBOutlet weak var lblPartySize: UILabel!
    @IBOutlet weak var lblSpaName: UILabel!
    @IBOutlet weak var lblReservationDate: UILabel!
    @IBOutlet weak var vwBorder: UIView!
    @IBOutlet weak var lblReservationTime: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        vwBorder.backgroundColor = UIColor.white
        vwBorder.layer.shadowColor = UIColor.lightGray.cgColor
        vwBorder.layer.shadowRadius = 2.0
        vwBorder.layer.shadowOffset = CGSize(width: 0, height: 0 )
        vwBorder.layer.shadowOpacity = 0.5
        // Configure the view for the selected state
    }

}
