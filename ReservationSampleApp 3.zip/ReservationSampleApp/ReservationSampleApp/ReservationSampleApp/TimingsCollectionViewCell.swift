//
//  TimingsCollectionViewCell.swift
//  ReservationSampleApp
//
//  Created by Subashree on 16/03/17.
//  Copyright © 2017 Subashree. All rights reserved.
//

import UIKit

class TimingsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var btnCellTapped: UIButton!
    @IBOutlet weak var vwBackground: UIView!
    @IBOutlet weak var lblTime: UILabel!
}
