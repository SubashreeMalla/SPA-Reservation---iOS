//
//  ViewController.swift
//  ReservationSampleApp
//
//  Created by Subashree on 15/03/17.
//  Copyright © 2017 Subashree. All rights reserved.
//

import UIKit

class SpaTypesViewController: UIViewController, UIScrollViewDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tblMessageList: UITableView!
    @IBOutlet weak var scrlVWBanners: UIScrollView!
    @IBOutlet weak var pageControl: SpaPageControl!
    var imagesArr:[UIImage] = [UIImage(named: "spa1")!, UIImage(named: "spa2")!, UIImage(named: "spa3")!]
    var messageTypesArr : [String] = ["Swedish Message", "Deep Tissue Message", "Hot Stone Message", "Reflexology", "Trigger Point Therapy"]
    var frame: CGRect = CGRect(x: 0, y: 0, width: 0, height: 0)
    enum SpaType: Int {
        case MothersDay, HotStone, DeepTissue
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.title = "SPA SERVICE"
        configurePageControl()
        configurePages()
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:" ", style:.plain, target:nil, action:nil)

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.view.bringSubview(toFront: self.pageControl);
        self.pageControl.updateDots()
    }
    
    // MARK : CREATES PAGES BASED ON THE INPUT IMAGES ARRAY
    func configurePages() {
        for index in 0...(imagesArr.count - 1) {
            frame.origin.x = self.view.frame.size.width * CGFloat(index)
            frame.size = self.scrlVWBanners.frame.size
            self.scrlVWBanners.isPagingEnabled = true
            //let subView = UIView(frame: frame)
            let vwSpaServiceDetails: SpaServiceDetailsView = SpaServiceDetailsView.instanceFromNib() as! SpaServiceDetailsView
            vwSpaServiceDetails.frame.origin.x = frame.origin.x
            vwSpaServiceDetails.imgVwSpaImage.image = imagesArr[index]
            vwSpaServiceDetails.btnReserve.tag = index
            vwSpaServiceDetails.btnReserve.addTarget(self, action: #selector(btnReserveTapped(sender:)), for: UIControlEvents.touchUpInside)
            self.scrlVWBanners .addSubview(vwSpaServiceDetails)
        }
        self.scrlVWBanners.contentSize = CGSize(width: self.view.frame.size.width * CGFloat(imagesArr.count), height: self.scrlVWBanners.frame.size.height)
        pageControl.addTarget(self, action: (#selector(changePage(sender:))), for: UIControlEvents.valueChanged)
    }
    
    func configurePageControl() {
        self.pageControl.numberOfPages = imagesArr.count
        self.pageControl.currentPage = 0
        self.pageControl.tintColor = UIColor.red
        self.view.addSubview(pageControl)
    }
    
    // MARK : TO CHANGE WHILE CLICKING ON PAGE CONTROL
    func changePage(sender: AnyObject) -> () {
        let pageCntrl = sender as! UIPageControl
        let x = CGFloat(pageCntrl.currentPage) * scrlVWBanners.frame.size.width
        scrlVWBanners.setContentOffset(CGPoint(x: x, y: 0), animated: true)
        self.pageControl.updateDots()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let pageNumber = round(scrollView.contentOffset.x / scrollView.frame.size.width)
        pageControl.currentPage = Int(pageNumber)
        self.pageControl.updateDots()
    }
    
    // MARK : TableView Delegate Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.messageTypesArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // create a new cell if needed or reuse an old one
        let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cellMassageType")! as UITableViewCell
        cell.textLabel?.text = self.messageTypesArr[indexPath.row]
        cell.accessoryType = UITableViewCellAccessoryType.disclosureIndicator
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 2{
            print("go to next screen")
            self.performSegue(withIdentifier: "showReservationScreen", sender: nil);
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 53.0
    }

    func btnReserveTapped(sender: AnyObject) -> () {
        print(sender.tag)
        if SpaType.HotStone.rawValue == sender.tag{
            print("go to next screen")
            self.performSegue(withIdentifier: "showReservationScreen", sender: nil);
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

