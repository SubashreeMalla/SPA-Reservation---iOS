//
//  SpaReservationViewController.swift
//  ReservationSampleApp
//
//  Created by Subashree on 15/03/17.
//  Copyright © 2017 Subashree. All rights reserved.
//

import UIKit

class SpaReservationViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tblReservations: UITableView!
    var arrReservations : [[String: String]]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "MY RESERVATIONS"
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:" ", style:.plain, target:nil, action:nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        arrReservations = UserDefaults.standard.value(forKey: "ReservationData") as! [[String : String]]!
        self.tblReservations.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK : TableView Delegate Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrReservations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : ReservationDetailsCell = tableView.dequeueReusableCell(withIdentifier: "ReservationDetailsCell") as! ReservationDetailsCell
        let dictReservation: [String: String] = self.arrReservations[indexPath.row]
        cell.lblReservationDate.text = dictReservation["date"]
        cell.lblReservationTime.text = dictReservation["time"]
        cell.lblSpaName.text = dictReservation["title"]
        cell.lblPartySize.text = "Party Size - " + dictReservation["partysize"]!
        cell.lblSpaCount.text = dictReservation["duration"]
        cell.lblSpaDetails.text = dictReservation["description"]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 254.0
    }

}
