//
//  SpaServiceDetailsView.swift
//  ReservationSampleApp
//
//  Created by Subashree on 15/03/17.
//  Copyright © 2017 Subashree. All rights reserved.
//

import UIKit

class SpaServiceDetailsView: UIView {

    @IBOutlet weak var btnReserve: UIButton!
    @IBOutlet weak var imgVwSpaImage: UIImageView!
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "SpaServiceDetailsView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
}
