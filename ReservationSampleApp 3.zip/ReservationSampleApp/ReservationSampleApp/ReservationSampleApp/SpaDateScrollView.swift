//
//  SpaDateScrollView.swift
//  ReservationSampleApp
//
//  Created by Subashree on 17/03/17.
//  Copyright © 2017 Subashree. All rights reserved.
//

import UIKit
protocol SpaDateScrollViewDelegate{
    func selectedDate(date:String)
}
class SpaDateScrollView: UIScrollView { // reusable scroll view date picker component
    
    let dateToday = Date()
    let calendar = Calendar.current
    var selectedDateIndex : Int!
    var delegateSpa: SpaDateScrollViewDelegate!
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        self.setupView()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    // MARK : CREATES DATE PICKER VIEW OVER A SCROLL VIEW
    func setupView() {
        let year = calendar.component(.year, from: dateToday)
        let month = calendar.component(.month, from: dateToday)
        // let day = calendar.component(.day, from: dateToday)
        
        let dateComponents = DateComponents(year: year, month: month)
        let date = calendar.date(from: dateComponents)!
        let range = calendar.range(of: .day, in: .month, for: date)!
        let numDays = range.count
        print(numDays) // 31
        
        self.contentSize = CGSize(width: 64 * numDays, height: 100)
        for index in 0...(numDays - 1){
            let vwDate = UIView(frame: CGRect(x: index * 64, y: 0, width: 64, height: 100))
            let imgCalender = UIView (frame: CGRect(x: 4, y: 12, width: 56, height: 76))
            imgCalender.layer.shadowColor = UIColor.lightGray.cgColor
            imgCalender.layer.shadowRadius = 2.0
            imgCalender.layer.shadowOffset = CGSize(width: 0, height: 0 )
            imgCalender.layer.shadowOpacity = 0.5
            imgCalender.backgroundColor = UIColor.white
            
            let vwHeader = UIView (frame: CGRect(x: 4, y: 12, width: 56, height: 15))
            vwHeader.backgroundColor = UIColor(colorLiteralRed: 19.0/255.0, green: 109.0/255.0, blue: 194.0/255.0, alpha: 1.0)
            
            let lblDay = UILabel (frame: CGRect(x: 4, y: 25, width: 56, height: 40))
            lblDay.textAlignment = .center
            lblDay.font = UIFont(name: "Helvetica", size: 12)
            lblDay.textColor = UIColor.gray
            lblDay.tag = 100 + index
            
            let lblDate = UILabel (frame: CGRect(x: 4, y: 43, width: 56, height: 40))
            lblDate.textAlignment = .center
            lblDate.font = UIFont(name: "Helvetica", size: 17)
            lblDate.textColor = UIColor.black
            
            var strcurrentDate:String = ""
            strcurrentDate = strcurrentDate.appendingFormat("%02d", (index + 1))
            lblDate.text = strcurrentDate
            
            var strcurrentDay: String = ""
            strcurrentDay = strcurrentDay.appendingFormat("%d", year) + "-"
            strcurrentDay = strcurrentDay.appendingFormat("%02d", month) + "-"
            strcurrentDay = strcurrentDay.appendingFormat("%02d", (index + 1))
            
            let df = DateFormatter()
            df.dateFormat = "yyyy-MM-dd"
            let currentDate = df.date(from: strcurrentDay)
            let reminderDate = currentDate?.addingTimeInterval(Double(1) * 60 * 60 * 24)
            df.dateFormat  = "EE"//"EE" to get short style
            let dayInWeek = df.string(from: currentDate!)//"Sunday"
            lblDay.text = dayInWeek
            let btnSelect = UIButton(frame: CGRect(x: 4, y: 12, width: 56, height: 76))
            btnSelect.addTarget(self, action: #selector(DateSelectedScrl(sender:)), for: .touchUpInside)
            btnSelect.tag = index
            if reminderDate! < NSDate() as Date{
                vwDate.alpha = 0.3
                btnSelect.isUserInteractionEnabled = false
            }
            vwDate.addSubview(imgCalender)
            vwDate.addSubview(vwHeader)
            vwDate.addSubview(lblDay)
            vwDate.addSubview(lblDate)
            vwDate.addSubview(btnSelect)
            self.addSubview(vwDate)
        }

    }
    
    // MARK : ACTION PERFORMED WHEN A DATE IS SELECTED
    func DateSelectedScrl(sender: UIButton) {
        print(sender.tag)
        if self.selectedDateIndex != nil{
            let btnPrevSelected = self.viewWithTag(selectedDateIndex) as! UIButton
            //btnPrevSelected.backgroundColor = UIColor.clear
            btnPrevSelected.alpha = 1.0
            btnPrevSelected.setBackgroundImage(nil, for: .normal)
        }
        self.selectedDateIndex = sender.tag
        sender.alpha = 0.5
        sender.setBackgroundImage(UIImage(named: "tick"), for: .normal)
        print(sender.tag + 1)
        let lblSelectedDay = self.viewWithTag(100 + sender.tag) as! UILabel
        print(lblSelectedDay.text!)
        let selectedDate = String(sender.tag + 1) + " " + lblSelectedDay.text!
        self.delegateSpa.selectedDate(date: selectedDate)
    }
}
