//
//  ReservationViewController.swift
//  ReservationSampleApp
//
//  Created by Subashree on 15/03/17.
//  Copyright © 2017 Subashree. All rights reserved.
//

import UIKit

class ReservationViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource,SpaDateScrollViewDelegate{
    @IBOutlet weak var lblSpaDetails: UILabel!
    @IBOutlet weak var txtPartySize: UITextField!
    @IBOutlet weak var vwHeaderBG: UIView!
    @IBOutlet weak var btnReserve: UIButton!
    @IBOutlet weak var scrlDates: SpaDateScrollView!
    @IBOutlet weak var lblSpaTitle: UILabel!
    @IBOutlet weak var lblSelectedMonth: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var collectionViewTimings: UICollectionView!
    let pickOption: [String] = ["1","2","3","4","5","6","7","8","9","10","11","12"]
    var pickerView: UIPickerView!
    var pickerPrevSelectedOption: Int!
    var selectedDateIndex : Int!
    var selectedTime: String!
    var selectedDate: String!
    var timingsOptions = ["09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "01:00 PM", "02:00 PM", "03:00 PM","04:00 PM","05:00 PM","06:00 PM","07:00 PM","08:00 PM"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "SCHEDULE"
        self.btnReserve.alpha = 0.5
        self.configurePickerView()
       // self.configureDateView()
        self.collectionViewTimings.allowsSelection = true //this is set by default
        self.collectionViewTimings.dataSource = self
        self.collectionViewTimings.delegate = self
        scrlDates.delegateSpa = self;
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        vwHeaderBG.layer.shadowColor = UIColor.lightGray.cgColor
        vwHeaderBG.layer.shadowRadius = 2.0
        vwHeaderBG.layer.shadowOffset = CGSize(width: 0, height: 0 )
        vwHeaderBG.layer.shadowOpacity = 0.5
    }

    func configurePickerView() {
        pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.backgroundColor = UIColor.white
        pickerPrevSelectedOption = 0
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.lightGray
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(donePickerTapped))
        doneButton.tintColor = UIColor(displayP3Red: 17.0/255.0, green: 109.0/255.0, blue: 184.0/255.0, alpha: 1.0)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action: #selector(cancelPickerTapped))
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        txtPartySize.inputView = pickerView
        txtPartySize.inputAccessoryView = toolBar
    }
    
    func donePickerTapped() {
        pickerPrevSelectedOption = pickerView.selectedRow(inComponent: 0)
        self.txtPartySize.endEditing(true)
    }
    
    func cancelPickerTapped() {
        self.txtPartySize.endEditing(true)
        self.pickerView.selectRow(pickerPrevSelectedOption, inComponent: 0, animated: false)
        self.txtPartySize.text = self.pickOption[pickerPrevSelectedOption]
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return pickOption.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickOption[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txtPartySize.text = pickOption[row]
    }
    
    func selectedDate(date:String){
        self.selectedDate = date
        if selectedTime != nil{
            self.btnReserve.alpha = 1.0
        }
    }
    
    // MARK : COLLECTION VIEW DELEGATE METHODS
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return timingsOptions.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell: TimingsCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "TimingsCollectionViewCell", for: indexPath) as! TimingsCollectionViewCell
        cell.vwBackground.layer.shadowColor = UIColor.lightGray.cgColor
        cell.vwBackground.layer.shadowRadius = 2.0
        cell.vwBackground.layer.shadowOffset = CGSize(width: 0, height: 0 )
        cell.vwBackground.layer.shadowOpacity = 0.5
        cell.lblTime.text = timingsOptions[indexPath.row]
        cell.btnCellTapped.addTarget(self, action: #selector(collectionviewCellTapped(sender:)), for: .touchUpInside)
        cell.btnCellTapped.tag = indexPath.row + 200
        cell.lblTime.tag = indexPath.row + 250
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 110, height: 45)
    }
    
    private func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: IndexPath) {
        if let cell:TimingsCollectionViewCell = collectionView.cellForItem(at: indexPath) as? TimingsCollectionViewCell {
            selectedTime = cell.lblTime.text
            if selectedDate != nil{
                self.btnReserve.alpha = 1.0
            }
        } else {
            // Error indexPath is not on screen: this should never happen.
        }
    }
    
    func collectionviewCellTapped(sender: UIButton) {
        if self.selectedTime != nil{
            let btnPrevSelected = self.view.viewWithTag((timingsOptions.index(of: selectedTime)! + 200)) as! UIButton
            //btnPrevSelected.backgroundColor = UIColor.clear
            btnPrevSelected.alpha = 1.0
            btnPrevSelected.setBackgroundImage(nil, for: .normal)
        }

        let lblTimings = self.collectionViewTimings.viewWithTag(sender.tag + 50) as! UILabel
        sender.setBackgroundImage(UIImage(named: "tickTimings"), for: .normal)
        sender.alpha = 0.5
        self.selectedTime = lblTimings.text!
        if selectedDate != nil{
            self.btnReserve.alpha = 1.0
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnReserveTapped(_ sender: Any) {
        let strDayDate: [String] = selectedDate.components(separatedBy: " ")
        var dates = strDayDate[1] + ", "
        dates = dates.appending(lblSelectedMonth.text!.capitalized) + " "
        dates = dates.appending(strDayDate[0]) + ", "
        dates = dates.appending("2017")
        let dictReservation: [String: String] =  ["date": dates, "time" : selectedTime, "title" : lblSpaTitle.text!, "partysize": self.txtPartySize.text!, "duration": lblDuration.text!, "description": lblSpaDetails.text!]
        
        var arrReservations: [[String: String]] = UserDefaults.standard.value(forKey: "ReservationData") as! [[String : String]]
        arrReservations.append(dictReservation)
        UserDefaults.standard.setValue(arrReservations, forKey: "ReservationData")
        self.navigationController?.popToRootViewController(animated: true)
        print(dictReservation)
    }
    @IBAction func btnViewCalenderTapped(_ sender: Any) {
        // Opens phones calendar to check the other appointments which have been already marked
        let url = NSURL(string: "calshow://")!
        UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
    }
}

extension NSDate: Comparable { // EXTENSION FOR NSDATE TO COMPARE DATES
    static public func ==(lhs: NSDate, rhs: NSDate) -> Bool {
        return lhs === rhs || lhs.compare(rhs as Date) == .orderedSame
    }
    
    static public func <(lhs: NSDate, rhs: NSDate) -> Bool {
        return lhs.compare(rhs as Date) == .orderedAscending
    }
    
    func addDays(daysToAdd: Int) -> NSDate {
        let secondsInDays: TimeInterval = Double(daysToAdd) * 60 * 60 * 24
        let dateWithDaysAdded: NSDate = self.addingTimeInterval(secondsInDays)
        return dateWithDaysAdded
    }
}
